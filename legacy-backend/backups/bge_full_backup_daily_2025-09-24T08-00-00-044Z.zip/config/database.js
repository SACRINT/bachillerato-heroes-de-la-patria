/**
 * 🗄️ CONFIGURACIÓN DE BASE DE DATOS
 * Conexión MySQL con fallback a sistema JSON
 */

const mysql = require('mysql2/promise');
const jsonDb = require('./database-json');
require('dotenv').config();

// Flag para determinar qué sistema usar
let useJsonFallback = false;

// Configuración del pool de conexiones (compatible MySQL2)
const poolConfig = {
    host: process.env.DB_HOST || 'localhost',
    port: process.env.DB_PORT || 3306,
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'heroes_patria_db',
    waitForConnections: true,
    connectionLimit: parseInt(process.env.DB_CONNECTION_LIMIT) || 10,
    queueLimit: 0,
    charset: process.env.DB_CHARSET || 'utf8mb4',
    timezone: process.env.DB_TIMEZONE || 'Z',
    ssl: process.env.DB_SSL === 'true' ? true : false
};

// Crear pool de conexiones
const pool = mysql.createPool(poolConfig);

/**
 * Ejecutar query con manejo de errores y fallback JSON
 * @param {string} query - SQL query
 * @param {Array} params - Parámetros del query
 * @returns {Promise<Array>} Resultado del query
 */
async function executeQuery(query, params = []) {
    // Si está activado el fallback JSON, usar ese sistema
    if (useJsonFallback) {
        return await jsonDb.executeQuery(query, params);
    }

    try {
        const [rows] = await pool.execute(query, params);
        return rows;
    } catch (error) {
        console.error('❌ Error en MySQL, activando fallback JSON:', error.message);

        // Activar fallback automáticamente
        useJsonFallback = true;
        console.log('🔄 Cambiando a sistema JSON temporal...');

        return await jsonDb.executeQuery(query, params);
    }
}

/**
 * Ejecutar múltiples queries en transacción
 * @param {Array} queries - Array de objetos {query, params}
 * @returns {Promise<Array>} Resultados de los queries
 */
async function executeTransaction(queries) {
    const connection = await pool.getConnection();
    
    try {
        await connection.beginTransaction();
        
        const results = [];
        for (const {query, params = []} of queries) {
            const [result] = await connection.execute(query, params);
            results.push(result);
        }
        
        await connection.commit();
        return results;
    } catch (error) {
        await connection.rollback();
        console.error('❌ Error en transacción:', error.message);
        throw error;
    } finally {
        connection.release();
    }
}

/**
 * Test de conexión a la base de datos con fallback
 */
async function testConnection() {
    // Si ya está usando JSON, testear ese sistema
    if (useJsonFallback) {
        return await jsonDb.testConnection();
    }

    try {
        const connection = await pool.getConnection();
        console.log('✅ Conexión a MySQL establecida correctamente');

        // Verificar versión de MySQL
        const [rows] = await connection.execute('SELECT VERSION() as version');
        console.log(`📊 MySQL Version: ${rows[0].version}`);

        connection.release();
        return true;
    } catch (error) {
        console.error('❌ Error conectando a MySQL:', error.message);
        console.error('🔧 Config:', {
            host: poolConfig.host,
            port: poolConfig.port,
            database: poolConfig.database,
            user: poolConfig.user
        });

        // Activar fallback automáticamente
        console.log('🔄 Activando sistema JSON como fallback...');
        useJsonFallback = true;
        return await jsonDb.testConnection();
    }
}

/**
 * Cerrar pool de conexiones o sistema JSON
 */
async function closePool() {
    if (useJsonFallback) {
        return await jsonDb.closePool();
    }

    try {
        await pool.end();
        console.log('✅ Pool de conexiones cerrado');
    } catch (error) {
        console.error('❌ Error cerrando pool:', error.message);
    }
}

/**
 * Obtener estadísticas del pool o sistema JSON
 */
async function getPoolStats() {
    if (useJsonFallback) {
        return await jsonDb.getPoolStats();
    }

    try {
        return {
            totalConnections: pool.pool._allConnections.length,
            freeConnections: pool.pool._freeConnections.length,
            acquiringConnections: pool.pool._acquiringConnections.length,
            tipo: 'MySQL'
        };
    } catch {
        return {
            totalConnections: 0,
            freeConnections: 0,
            acquiringConnections: 0,
            tipo: 'MySQL-Error'
        };
    }
}

module.exports = {
    pool,
    executeQuery,
    executeTransaction,
    testConnection,
    closePool,
    getPoolStats
};