/**
 * 🔐 MIDDLEWARE DE AUTENTICACIÓN
 * Sistema JWT para proteger rutas sensibles
 */

const jwt = require('jsonwebtoken');
const { executeQuery } = require('../config/database');

/**
 * Middleware para verificar JWT token
 */
const authenticateToken = async (req, res, next) => {
    try {
        const authHeader = req.headers['authorization'];
        const token = authHeader && authHeader.split(' ')[1]; // Bearer TOKEN
        
        if (!token) {
            return res.status(401).json({
                error: 'Token de acceso requerido',
                message: 'Debes estar autenticado para acceder a este recurso'
            });
        }
        
        // Verificar token
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        
        // Verificar que el usuario siga existiendo y activo (adaptado para JSON)
        const users = await executeQuery(
            'SELECT * FROM usuarios WHERE id = ?',
            [decoded.userId]
        );

        const user = users.find(u => u.id === decoded.userId);

        if (!user || !user.active) {
            return res.status(401).json({
                error: 'Token inválido',
                message: 'El usuario no existe o está inactivo'
            });
        }

        // Agregar información del usuario al request
        req.user = {
            id: user.id,
            email: user.email,
            username: user.username,
            role: user.role,
            active: user.active
        };

        // Simular actualización de último acceso (en sistema JSON)
        console.log(`👤 Usuario autenticado: ${user.username} (${user.role})`);
        
        next();
    } catch (error) {
        if (error.name === 'JsonWebTokenError') {
            return res.status(403).json({
                error: 'Token inválido',
                message: 'El token proporcionado no es válido'
            });
        }
        
        if (error.name === 'TokenExpiredError') {
            return res.status(403).json({
                error: 'Token expirado',
                message: 'El token ha expirado, por favor inicia sesión nuevamente'
            });
        }
        
        console.error('Error en middleware de autenticación:', error);
        res.status(500).json({
            error: 'Error interno del servidor',
            message: 'Error verificando autenticación'
        });
    }
};

/**
 * Middleware para verificar roles específicos
 */
const requireRole = (allowedRoles) => {
    return (req, res, next) => {
        if (!req.user) {
            return res.status(401).json({
                error: 'No autenticado',
                message: 'Debes estar autenticado para acceder'
            });
        }
        
        if (!allowedRoles.includes(req.user.role)) {
            return res.status(403).json({
                error: 'Acceso denegado',
                message: `Se requiere rol: ${allowedRoles.join(' o ')}`,
                userRole: req.user.role
            });
        }
        
        next();
    };
};

/**
 * Middleware para verificar si es administrador
 */
const requireAdmin = requireRole(['admin']);

/**
 * Middleware para verificar si es docente o superior
 */
const requireTeacher = requireRole(['teacher', 'admin']);

/**
 * Generar JWT token
 */
const generateToken = (user) => {
    const payload = {
        userId: user.id,
        email: user.email,
        username: user.username,
        role: user.role
    };

    return jwt.sign(payload, process.env.JWT_SECRET, {
        expiresIn: '24h',
        issuer: 'heroes-patria-api',
        subject: user.id.toString()
    });
};

/**
 * Generar refresh token
 */
const generateRefreshToken = (user) => {
    const payload = {
        userId: user.id,
        type: 'refresh'
    };
    
    return jwt.sign(payload, process.env.JWT_SECRET, {
        expiresIn: '7d',
        issuer: 'heroes-patria-api',
        subject: user.id.toString()
    });
};

module.exports = {
    authenticateToken,
    requireRole,
    requireAdmin,
    requireTeacher,
    generateToken,
    generateRefreshToken
};