/**
 * 🎓 BACKEND API - BACHILLERATO HÉROES DE LA PATRIA
 * Sistema de gestión académica con integración de chatbot inteligente
 */

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const compression = require('compression');
const rateLimit = require('express-rate-limit');
const path = require('path');
require('dotenv').config();

// Importar rutas
const authRoutes = require('./routes/auth');
const dashboardRoutes = require('./routes/dashboard');
const gamificationRoutes = require('./routes/gamification');
const chatbotRoutes = require('./routes/chatbot');
const studentsRoutes = require('./routes/students');
const teachersRoutes = require('./routes/teachers');
const informationRoutes = require('./routes/information');
const analyticsRoutes = require('./routes/analytics');
const backupRoutes = require('./routes/backup');
const sslRoutes = require('./routes/ssl');
const maintenanceRoutes = require('./routes/maintenance');
const notificationsRoutes = require('./routes/notifications');
const cmsRoutes = require('./routes/cms');
const uploadsRoutes = require('./routes/uploads');
const calendarRoutes = require('./routes/calendar');
const gradesAnalyticsRoutes = require('./routes/gradesAnalytics');
const parentTeacherCommunicationRoutes = require('./routes/parentTeacherCommunication');

// Importar middlewares
const { authenticateToken } = require('./middleware/auth');
const { errorHandler } = require('./middleware/errorHandler');
const { requestLogger } = require('./middleware/logger');

const app = express();
const PORT = process.env.PORT || 3000;
const http = require('http');
const server = http.createServer(app);

// ============================================
// MIDDLEWARES DE SEGURIDAD
// ============================================

// Helmet para headers de seguridad
app.use(helmet({
    contentSecurityPolicy: {
        directives: {
            defaultSrc: ["'self'"],
            styleSrc: ["'self'", "'unsafe-inline'", "https://cdn.jsdelivr.net", "https://cdnjs.cloudflare.com"],
            scriptSrc: ["'self'", "https://cdn.jsdelivr.net"],
            imgSrc: ["'self'", "data:", "https:"],
            fontSrc: ["'self'", "https://cdnjs.cloudflare.com"],
            connectSrc: ["'self'"]
        }
    }
}));

// CORS configurado
const corsOptions = {
    origin: function (origin, callback) {
        const allowedOrigins = process.env.ALLOWED_ORIGINS?.split(',') || [
            'http://localhost:8080',
            'http://127.0.0.1:8081',
            'https://sacrint.github.io'
        ];
        
        if (!origin || allowedOrigins.indexOf(origin) !== -1) {
            callback(null, true);
        } else {
            callback(new Error('No permitido por CORS'));
        }
    },
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'],
    allowedHeaders: ['Content-Type', 'Authorization']
};
app.use(cors(corsOptions));

// Rate limiting
const limiter = rateLimit({
    windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 15 * 60 * 1000, // 15 minutos
    max: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS) || 100,
    message: {
        error: 'Demasiadas solicitudes desde esta IP, intenta de nuevo más tarde.',
        retryAfter: '15 minutos'
    },
    standardHeaders: true,
    legacyHeaders: false
});
app.use('/api/', limiter);

// Compresión
app.use(compression());

// Logging
app.use(morgan('combined'));
app.use(requestLogger);

// Body parsers
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// ============================================
// RUTAS DE LA API
// ============================================

// Ruta de salud del servidor
app.get('/health', async (req, res) => {
    let dbStatus = 'disconnected';
    let dbInfo = {};

    if (req.app.locals.dbAvailable) {
        try {
            const db = require('./config/database');
            const isConnected = await db.testConnection();

            if (isConnected) {
                dbStatus = 'connected';
                dbInfo = db.getPoolStats();
            }
        } catch (error) {
            dbStatus = 'error';
            dbInfo = { error: error.message };
        }
    }

    res.json({
        status: 'OK',
        timestamp: new Date().toISOString(),
        environment: process.env.NODE_ENV || 'development',
        version: '1.0.0',
        uptime: process.uptime(),
        database: {
            status: dbStatus,
            info: dbInfo
        },
        fase1: {
            mysql: dbStatus === 'connected' ? '✅ Conectado' : '⚠️ Pendiente instalación',
            backend: '✅ Funcional',
            config: '✅ Configurado'
        }
    });
});

// Rutas principales
app.use('/api/auth', authRoutes);
app.use('/api/dashboard', dashboardRoutes);
app.use('/api/gamification', gamificationRoutes);
app.use('/api/chatbot', chatbotRoutes);
app.use('/api/students', studentsRoutes);
app.use('/api/teachers', teachersRoutes);
app.use('/api/information', informationRoutes);
app.use('/api/analytics', analyticsRoutes);
app.use('/api/backup', backupRoutes);
app.use('/api/ssl', sslRoutes);
app.use('/api/maintenance', maintenanceRoutes);
app.use('/api/notifications', notificationsRoutes);
app.use('/api/cms', cmsRoutes);
app.use('/api/uploads', uploadsRoutes);
app.use('/api/calendar', calendarRoutes);
app.use('/api/grades-analytics', gradesAnalyticsRoutes);
app.use('/api/parent-teacher', parentTeacherCommunicationRoutes);

// Documentación de API (Swagger)
if (process.env.NODE_ENV !== 'production') {
    const swaggerUi = require('swagger-ui-express');
    const swaggerSpec = require('./config/swagger');
    
    app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec, {
        explorer: true,
        customCssUrl: 'https://cdnjs.cloudflare.com/ajax/libs/swagger-ui/4.15.5/swagger-ui.min.css'
    }));
    
    console.log(`📚 Documentación API disponible en: http://localhost:${PORT}/api-docs`);
}

// Ruta 404 para API
app.use('/api/*', (req, res) => {
    res.status(404).json({
        error: 'Endpoint no encontrado',
        path: req.path,
        method: req.method,
        timestamp: new Date().toISOString()
    });
});

// Servir archivos estáticos (para desarrollo)
console.log('NODE_ENV:', process.env.NODE_ENV || 'development');
if (!process.env.NODE_ENV || process.env.NODE_ENV === 'development') {
    console.log('🌐 Configurando servidor de archivos estáticos...');
    app.use(express.static(path.join(__dirname, '../')));

    app.get('/', (req, res) => {
        console.log('📄 Sirviendo index.html');
        res.sendFile(path.join(__dirname, '../index.html'));
    });

    // Ruta catch-all para archivos HTML
    app.get('*.html', (req, res) => {
        const fileName = req.params[0] + '.html';
        const filePath = path.join(__dirname, '../', fileName);
        console.log('📄 Sirviendo:', fileName);
        res.sendFile(filePath, (err) => {
            if (err) {
                res.status(404).send('Archivo no encontrado');
            }
        });
    });
}

// ============================================
// MANEJO DE ERRORES
// ============================================
app.use(errorHandler);

// Manejo de errores no capturados
process.on('uncaughtException', (error) => {
    console.error('💥 Uncaught Exception:', error);
    process.exit(1);
});

process.on('unhandledRejection', (error) => {
    console.error('💥 Unhandled Rejection:', error);
    process.exit(1);
});

// ============================================
// INICIO DEL SERVIDOR
// ============================================
server.listen(PORT, async () => {
    console.log(`🚀 Servidor iniciado en puerto ${PORT}`);
    console.log(`🌐 Ambiente: ${process.env.NODE_ENV || 'development'}`);
    console.log(`📡 API Base URL: http://localhost:${PORT}/api`);
    console.log(`❤️  Health Check: http://localhost:${PORT}/health`);

    // Inicializar sistema de backup automático
    try {
        const { getBackupService } = require('./services/backupService');
        getBackupService();
        console.log('💾 Sistema de backup automático inicializado');
    } catch (error) {
        console.log('⚠️  Sistema de backup no disponible:', error.message);
    }

    // Inicializar servicio de notificaciones push
    try {
        const { getPushNotificationService } = require('./services/pushNotificationService');
        getPushNotificationService();
        console.log('📱 Sistema de notificaciones push inicializado');
    } catch (error) {
        console.log('⚠️  Sistema de notificaciones no disponible:', error.message);
    }

    // Inicializar servicio WebSocket
    try {
        const { getWebSocketService } = require('./services/webSocketService');
        const wsService = getWebSocketService();
        wsService.initialize(server);
        console.log('🌐 Sistema WebSocket inicializado');
    } catch (error) {
        console.log('⚠️  Sistema WebSocket no disponible:', error.message);
    }

    // Test de conexión a base de datos con manejo de errores mejorado
    try {
        const db = require('./config/database');
        const isConnected = await db.testConnection();

        if (isConnected) {
            console.log('✅ FASE 1: Base de datos MySQL conectada - Sistema funcional');
            // Marcar como disponible globalmente
            app.locals.dbAvailable = true;
        } else {
            console.log('⚠️  FASE 1: MySQL no disponible - Funcionando en modo degradado');
            console.log('📋 Para instalar MySQL: ver docs/SETUP_MYSQL.md');
            app.locals.dbAvailable = false;
        }
    } catch (error) {
        console.log('⚠️  FASE 1: MySQL no disponible - Funcionando en modo degradado');
        console.log('📋 Para instalar MySQL: ver docs/SETUP_MYSQL.md');
        console.log('🔧 Error:', error.message);
        app.locals.dbAvailable = false;
    }
});

// Graceful shutdown
process.on('SIGTERM', () => {
    console.log('🛑 SIGTERM recibido, cerrando servidor...');

    // Cerrar servidor WebSocket
    try {
        const { getWebSocketService } = require('./services/webSocketService');
        const wsService = getWebSocketService();
        wsService.shutdown();
    } catch (error) {
        console.log('⚠️  Error cerrando WebSocket:', error.message);
    }

    server.close(() => {
        console.log('✅ Servidor cerrado correctamente');
        process.exit(0);
    });
});

module.exports = app;